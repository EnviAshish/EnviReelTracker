# Build the APK

This environment does not include the Android SDK or Gradle and cannot download them, so it cannot produce a verified APK binary here. The full Android Studio project is included.

To build locally, follow the steps in `README.md`.

Alternatively, push this project to a GitHub repository and run the **Build ENVI REEL TRACKER APK** workflow from the Actions tab. It uploads `app-debug.apk` as a workflow artifact.
