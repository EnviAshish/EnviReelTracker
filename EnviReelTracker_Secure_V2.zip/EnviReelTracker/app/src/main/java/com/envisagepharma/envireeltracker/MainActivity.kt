package com.envisagepharma.envireeltracker

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var totalValue: TextView
    private lateinit var instagramValue: TextView
    private lateinit var youtubeValue: TextView
    private lateinit var screenTimeValue: TextView
    private lateinit var limitValue: TextView
    private lateinit var permissions: TextView
    private lateinit var history: TextView
    private lateinit var limitInput: EditText

    private val bg = Color.rgb(7, 27, 24)
    private val panel = Color.rgb(18, 48, 41)
    private val lime = Color.rgb(178, 240, 92)
    private val muted = Color.rgb(190, 207, 199)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 40)
        }
    }

    override fun onResume() { super.onResume(); if (::totalValue.isInitialized) refresh() }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(30)) }
        scroll.addView(root)
        setContentView(scroll)

        text("ENVI REEL TRACKER", 26, lime, true)
        text("LEARN  •  TRACK  •  TAKE CONTROL", 12, muted, true).setPadding(0, dp(3), 0, dp(18))

        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); setBackgroundColor(panel) }
        val heroLabel = TextView(this).apply { text = "TODAY'S ESTIMATED COUNT"; textSize = 12f; setTextColor(muted) }
        totalValue = TextView(this).apply { text = "0"; textSize = 42f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD) }
        val heroSub = TextView(this).apply { text = "Reels + Shorts tracked on this device"; textSize = 12f; setTextColor(muted) }
        hero.addView(heroLabel); hero.addView(totalValue); hero.addView(heroSub)
        root.addView(hero, matchWrap())

        section("TODAY AT A GLANCE")
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val wide = resources.configuration.screenWidthDp >= 600
        val firstRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        instagramValue = statCard(firstRow, "INSTAGRAM REELS", "0", wide)
        youtubeValue = statCard(firstRow, "YOUTUBE SHORTS", "0", wide)
        if (wide) {
            screenTimeValue = statCard(firstRow, "APP SCREEN TIME", "0m", wide)
            limitValue = statCard(firstRow, "DAILY LIMIT", "100", wide)
            grid.addView(firstRow, matchWrap())
        } else {
            grid.addView(firstRow, matchWrap())
            val secondRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            screenTimeValue = statCard(secondRow, "APP SCREEN TIME", "0m", wide)
            limitValue = statCard(secondRow, "DAILY LIMIT", "100", wide)
            grid.addView(secondRow, matchWrap())
        }
        root.addView(grid, matchWrap())

        section("QUICK ACTIONS")
        val quick = LinearLayout(this).apply { orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        actionButton(quick, "+ Instagram Reel") { TrackerStore.increment(this, ReelAccessibilityService.INSTAGRAM); refresh() }
        actionButton(quick, "+ YouTube Short") { TrackerStore.increment(this, ReelAccessibilityService.YOUTUBE); refresh() }
        root.addView(quick, matchWrap())

        section("DAILY LIMIT")
        limitInput = EditText(this).apply {
            setText(TrackerStore.limit(this@MainActivity).toString())
            hint = "Enter daily limit"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(muted)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(panel)
        }
        root.addView(limitInput, matchWrap())
        button("Save daily limit") {
            val value = limitInput.text.toString().toIntOrNull()
            if (value == null || value < 1) toast("Enter a limit greater than zero")
            else { TrackerStore.setLimit(this, value); refresh(); toast("Daily limit saved") }
        }

        section("SETUP & PERMISSIONS")
        permissions = TextView(this).apply { textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(14), dp(12), dp(14), dp(12)); setBackgroundColor(panel) }
        root.addView(permissions, matchWrap())
        button("Open Accessibility Settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("Open Usage Access Settings") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        button("Open Notification Settings") {
            if (Build.VERSION.SDK_INT >= 26) startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }

        section("7-DAY HISTORY")
        history = TextView(this).apply { textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(14), dp(12), dp(14), dp(12)); setBackgroundColor(panel) }
        root.addView(history, matchWrap())

        section("PRIVACY & ACCURACY")
        text("Your counts and usage summaries are stored locally on this device. The counter estimates activity from Android scroll events limited to Instagram and YouTube. It cannot identify every Reel or Short exactly: ordinary feed scrolling may sometimes count, and some app versions may not report every swipe. Screen time is total foreground time in Instagram and YouTube, not Reels/Shorts-only time. This app does not need access to read on-screen content.", 12, muted, false)
        refresh()
    }

    private fun statCard(parent: LinearLayout, label: String, initial: String, wide: Boolean): TextView {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(13), dp(13), dp(13)); setBackgroundColor(panel) }
        val title = TextView(this).apply { text = label; textSize = 10f; setTextColor(muted) }
        val value = TextView(this).apply { text = initial; textSize = 23f; setTextColor(lime); setTypeface(typeface, android.graphics.Typeface.BOLD) }
        card.addView(title); card.addView(value)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { if (parent.childCount == 1) leftMargin = dp(7) else rightMargin = dp(7); bottomMargin = dp(8) }
        parent.addView(card, lp)
        return value
    }

    private fun actionButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = makeButton(label, action)
        val lp = if (resources.configuration.screenWidthDp >= 600) LinearLayout.LayoutParams(0, dp(50), 1f).apply { rightMargin = dp(6) } else matchWrap()
        parent.addView(b, lp)
    }

    private fun refresh() {
        val instagram = TrackerStore.count(this, ReelAccessibilityService.INSTAGRAM)
        val youtube = TrackerStore.count(this, ReelAccessibilityService.YOUTUBE)
        val total = instagram + youtube
        val igTime = usageMinutes(ReelAccessibilityService.INSTAGRAM)
        val ytTime = usageMinutes(ReelAccessibilityService.YOUTUBE)
        totalValue.text = total.toString()
        instagramValue.text = instagram.toString()
        youtubeValue.text = youtube.toString()
        screenTimeValue.text = formatMinutes(igTime + ytTime)
        val limit = TrackerStore.limit(this)
        limitValue.text = "$limit  •  ${if (total >= limit) "Reached" else "${limit - total} left"}"
        val notificationGranted = Build.VERSION.SDK_INT < 33 || checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        permissions.text = "Accessibility counter: ${if (accessibilityEnabled()) "ENABLED" else "NOT ENABLED"}\nUsage access: ${if (usageAccessGranted()) "GRANTED" else "NOT GRANTED"}\nNotifications: ${if (notificationGranted) "GRANTED" else "NOT GRANTED"}"
        history.text = (0..6).joinToString("\n\n") { offset ->
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }
            val key = TrackerStore.dayKey(cal.timeInMillis)
            val label = SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(Date(cal.timeInMillis))
            "$label     ${TrackerStore.total(this, key)} total  (IG ${TrackerStore.count(this, ReelAccessibilityService.INSTAGRAM, key)} • YT ${TrackerStore.count(this, ReelAccessibilityService.YOUTUBE, key)})"
        }
    }

    private fun usageMinutes(pkg: String): Long {
        if (!usageAccessGranted()) return 0
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val list: List<UsageStats> = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis()) ?: return 0
        return list.filter { it.packageName == pkg }.sumOf { it.totalTimeInForeground } / 60000L
    }

    private fun usageAccessGranted(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun accessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("$packageName/${ReelAccessibilityService::class.java.name}", true)
    }

    private fun section(label: String) {
        val t = TextView(this).apply { text = label; textSize = 14f; setTextColor(lime); setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(16), 0, dp(8)) }
        root.addView(t, matchWrap())
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) {
        val t = TextView(this).apply { text = value; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(4), 0, dp(4)) }
        root.addView(t, matchWrap())
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(28, 112, 77)); setOnClickListener { action() }
    }

    private fun button(label: String, action: () -> Unit) { root.addView(makeButton(label, action), matchWrap()) }
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun formatMinutes(minutes: Long): String = if (minutes < 60) "${minutes}m" else "${minutes / 60}h ${minutes % 60}m"
    private fun toast(message: String) = android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
}
