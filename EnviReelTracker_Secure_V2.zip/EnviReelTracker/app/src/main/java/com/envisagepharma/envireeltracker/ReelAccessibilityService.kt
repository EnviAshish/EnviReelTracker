package com.envisagepharma.envireeltracker

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

class ReelAccessibilityService : AccessibilityService() {
    private var lastCountAt = 0L
    private var lastPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != INSTAGRAM && pkg != YOUTUBE) return

        // TYPE_VIEW_SCROLLED is a best-effort signal. It is not proof that a new Reel/Short
        // appeared; app versions may omit it, and unrelated feed scrolling can trigger it.
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            val now = SystemClock.elapsedRealtime()
            if (lastPackage != pkg || now - lastCountAt >= DEBOUNCE_MS) {
                TrackerStore.increment(this, pkg)
                lastCountAt = now
                lastPackage = pkg
                maybeNotifyLimit()
            }
        }
    }

    private fun maybeNotifyLimit() {
        val total = TrackerStore.total(this)
        if (total < TrackerStore.limit(this) || TrackerStore.alerted(this)) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = "envi_limit"
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(channel, "Daily reel limit", NotificationManager.IMPORTANCE_DEFAULT))
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            android.app.Notification.Builder(this, channel)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("ENVI Reel Tracker")
                .setContentText("Daily limit reached: $total Reels/Shorts. Take a break!")
                .setAutoCancel(true).build()
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("ENVI Reel Tracker")
                .setContentText("Daily limit reached: $total Reels/Shorts. Take a break!")
                .setAutoCancel(true).build()
        }
        try { manager.notify(2001, notification); TrackerStore.markAlerted(this) } catch (_: SecurityException) { }
    }

    override fun onInterrupt() { }

    companion object {
        const val INSTAGRAM = "com.instagram.android"
        const val YOUTUBE = "com.google.android.youtube"
        private const val DEBOUNCE_MS = 850L
    }
}
