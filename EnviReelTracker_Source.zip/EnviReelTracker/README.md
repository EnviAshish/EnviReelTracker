# ENVI REEL TRACKER

A native Android starter app that tracks likely vertical-feed transitions in Instagram and YouTube, estimates each app's total foreground time, stores daily counts locally, shows a 7-day history, and can notify when a daily combined limit is reached.

## Important accuracy limits

- Instagram and YouTube do not expose a public API that tells another app the exact number of Reels or Shorts watched.
- This project uses Android Accessibility `TYPE_VIEW_SCROLLED` events as a best-effort signal. Some app/device versions may not expose every swipe. Other vertical scrolling inside the apps can occasionally be counted too. Treat the reel count as an estimate, not an audited exact count.
- Screen-time figures are total foreground time in the Instagram and YouTube apps. Android does not identify how much of that time was spent specifically on Reels or Shorts.
- The app does not capture screenshots, record video, read/store captions, or send usage data to a server. Counts and settings are stored locally in SharedPreferences.
- Accessibility permission is sensitive. Enable it only if you understand and accept the on-device monitoring described above.

## Build with Android Studio

1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this `EnviReelTracker` folder as an existing project.
3. Let Android Studio sync the Gradle project. Use JDK 17 and Gradle 8.9.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
6. Install the APK on the Android phone. On first launch:
   - Enable **1. Enable Reel Counter (Accessibility)** in Android Accessibility settings.
   - Grant **2. Allow Usage Access** for screen-time reports.
   - Allow notifications so daily-limit alerts can appear.

## Features in this first build

- Separate estimated counts for Instagram Reels and YouTube Shorts.
- Combined daily count and configurable daily limit.
- One daily limit notification per day (subject to Android notification permission).
- Instagram/YouTube total foreground screen time for today.
- Seven-day local count history.
- Manual +1 correction buttons if Android misses a transition.
- No login, cloud account, analytics SDK, or backend.

## Package details

- Application ID: `com.envisagepharma.envireeltracker`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- Version: 1.0.0 (debug build)

## Project structure

- `app/src/main/java/.../MainActivity.kt` — dashboard, permission links, limit, history, screen time.
- `app/src/main/java/.../ReelAccessibilityService.kt` — best-effort scroll event counter and limit notification.
- `app/src/main/java/.../TrackerStore.kt` — local daily data store.
