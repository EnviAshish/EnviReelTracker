package com.envisagepharma.envireeltracker

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var dashboard: TextView
    private lateinit var permissions: TextView
    private lateinit var history: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 40)
    }

    override fun onResume() { super.onResume(); if (::dashboard.isInitialized) refresh() }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(7, 27, 24)) }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 28) }
        scroll.addView(root)
        setContentView(scroll)

        text("ENVI REEL TRACKER", 25, Color.rgb(178, 240, 92), true)
        text("LEARN • TRACK • TAKE CONTROL", 12, Color.LTGRAY, true).setPadding(0, 4, 0, 20)
        dashboard = text("Loading today's usage…", 16, Color.WHITE, false)
        card(dashboard)

        text("SETUP", 17, Color.rgb(178, 240, 92), true).setPadding(0, 22, 0, 8)
        permissions = text("Checking permissions…", 14, Color.WHITE, false)
        card(permissions)
        button("1. Enable Reel Counter (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2. Allow Usage Access (screen-time reports)") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        button("3. Open Notification Settings") {
            if (Build.VERSION.SDK_INT >= 26) startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }

        text("DAILY LIMIT", 17, Color.rgb(178, 240, 92), true).setPadding(0, 22, 0, 8)
        val limitInput = EditText(this).apply {
            setText(TrackerStore.limit(this@MainActivity).toString())
            hint = "Daily Reel + Shorts limit"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        root.addView(limitInput, matchWrap())
        button("Save daily limit") {
            val value = limitInput.text.toString().toIntOrNull()
            if (value == null || value < 1) toast("Enter a limit greater than zero")
            else { TrackerStore.setLimit(this, value); refresh(); toast("Daily limit saved") }
        }

        text("COUNT CORRECTION", 17, Color.rgb(178, 240, 92), true).setPadding(0, 22, 0, 8)
        text("If Android misses a transition, you can correct today's count here.", 13, Color.LTGRAY, false)
        button("+1 Instagram Reel") { TrackerStore.increment(this, ReelAccessibilityService.INSTAGRAM); refresh() }
        button("+1 YouTube Short") { TrackerStore.increment(this, ReelAccessibilityService.YOUTUBE); refresh() }

        text("7-DAY HISTORY", 17, Color.rgb(178, 240, 92), true).setPadding(0, 22, 0, 8)
        history = text("", 14, Color.WHITE, false)
        card(history)
        text("PRIVACY & ACCURACY", 17, Color.rgb(178, 240, 92), true).setPadding(0, 22, 0, 8)
        text("All counts and reports stay on this device. The counter uses Android accessibility scroll events as an estimate; Instagram/YouTube do not provide a public API for exact Reel/Short views. Some app versions may not expose every swipe, and ordinary feed scrolls may occasionally be counted. Screen time is total time in Instagram/YouTube, not Shorts/Reels-only time.", 13, Color.LTGRAY, false)
        refresh()
    }

    private fun refresh() {
        val i = TrackerStore.count(this, ReelAccessibilityService.INSTAGRAM)
        val y = TrackerStore.count(this, ReelAccessibilityService.YOUTUBE)
        val total = i + y
        val iTime = usageMinutes(ReelAccessibilityService.INSTAGRAM)
        val yTime = usageMinutes(ReelAccessibilityService.YOUTUBE)
        dashboard.text = "TODAY'S ESTIMATED COUNT\n\n$total Reels / Shorts\n\nInstagram Reels     $i\nYouTube Shorts       $y\n\nAPP SCREEN TIME\nInstagram     ${formatMinutes(iTime)}\nYouTube       ${formatMinutes(yTime)}\nCombined      ${formatMinutes(iTime + yTime)}\n\nDaily limit     ${TrackerStore.limit(this)}   •   ${if (total >= TrackerStore.limit(this)) "Reached" else "${(TrackerStore.limit(this) - total)} remaining"}"
        permissions.text = "Accessibility counter: ${if (accessibilityEnabled()) "ENABLED" else "NOT ENABLED"}\nUsage access: ${if (usageAccessGranted()) "GRANTED" else "NOT GRANTED"}\nNotification permission: ${if (Build.VERSION.SDK_INT < 33 || checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) "GRANTED" else "NOT GRANTED"}"
        val lines = (0..6).joinToString("\n\n") { offset ->
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }
            val key = TrackerStore.dayKey(cal.timeInMillis)
            val label = SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(Date(cal.timeInMillis))
            "$label     ${TrackerStore.total(this, key)} total  (IG ${TrackerStore.count(this, ReelAccessibilityService.INSTAGRAM, key)} • YT ${TrackerStore.count(this, ReelAccessibilityService.YOUTUBE, key)})"
        }
        history.text = lines
    }

    private fun usageMinutes(pkg: String): Long {
        if (!usageAccessGranted()) return 0
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val list: List<UsageStats> = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis()) ?: return 0
        return list.filter { it.packageName == pkg }.sumOf { it.totalTimeInForeground } / 60000L
    }

    private fun usageAccessGranted(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun accessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("$packageName/${ReelAccessibilityService::class.java.name}", true)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, 5, 0, 5)
        root.addView(this, matchWrap())
    }

    private fun card(view: View) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14); setBackgroundColor(Color.rgb(18, 48, 41)) }
        (view.parent as? android.view.ViewGroup)?.removeView(view)
        wrap.addView(view)
        root.addView(wrap, matchWrap())
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(28, 112, 77)); setOnClickListener { action() } }
        root.addView(b, matchWrap())
    }

    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
    private fun formatMinutes(minutes: Long): String = "${minutes / 60}h ${minutes % 60}m"
    private fun toast(message: String) = android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
}
