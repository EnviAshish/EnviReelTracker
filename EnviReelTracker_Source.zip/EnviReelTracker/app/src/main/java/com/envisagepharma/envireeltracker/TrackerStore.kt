package com.envisagepharma.envireeltracker

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TrackerStore {
    private const val PREF = "envi_tracker"
    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun dayKey(time: Long = System.currentTimeMillis()) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(time))
    fun count(context: Context, packageName: String, day: String = dayKey()): Int = prefs(context).getInt("count_${day}_$packageName", 0)
    fun total(context: Context, day: String = dayKey()): Int = count(context, ReelAccessibilityService.INSTAGRAM, day) + count(context, ReelAccessibilityService.YOUTUBE, day)
    fun increment(context: Context, packageName: String) {
        val p = prefs(context); val key = "count_${dayKey()}_$packageName"
        p.edit().putInt(key, p.getInt(key, 0) + 1).apply()
    }
    fun setCount(context: Context, packageName: String, value: Int) {
        prefs(context).edit().putInt("count_${dayKey()}_$packageName", value.coerceAtLeast(0)).apply()
    }
    fun limit(context: Context) = prefs(context).getInt("daily_limit", 100)
    fun setLimit(context: Context, value: Int) { prefs(context).edit().putInt("daily_limit", value.coerceIn(1, 2000)).apply() }
    fun alerted(context: Context, day: String = dayKey()) = prefs(context).getBoolean("alerted_$day", false)
    fun markAlerted(context: Context, day: String = dayKey()) { prefs(context).edit().putBoolean("alerted_$day", true).apply() }
}
